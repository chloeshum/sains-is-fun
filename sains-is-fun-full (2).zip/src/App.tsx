import React from 'react'
import ScienceQuizGame from './components/ScienceQuizGame'

export default function App() {
  return <ScienceQuizGame />
}
