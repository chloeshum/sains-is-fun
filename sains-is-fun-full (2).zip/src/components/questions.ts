export const allQuestions = {
  easy: [
    {
      text: "What planet is known as the Red Planet?",
      options: ["Earth", "Mars", "Jupiter", "Venus"],
      correctIndex: 1,
    },
    {
      text: "What do plants need for photosynthesis?",
      options: ["Water", "Sunlight", "Carbon Dioxide", "All of the above"],
      correctIndex: 3,
    }
  ],
  medium: [
    {
      text: "Which part of the cell contains DNA?",
      options: ["Cytoplasm", "Nucleus", "Mitochondria", "Ribosome"],
      correctIndex: 1,
    },
    {
      text: "What gas do humans breathe in?",
      options: ["Carbon Dioxide", "Hydrogen", "Oxygen", "Nitrogen"],
      correctIndex: 2,
    }
  ],
  hard: [
    {
      text: "What is the powerhouse of the cell?",
      options: ["Nucleus", "Ribosome", "Mitochondria", "Endoplasmic Reticulum"],
      correctIndex: 2,
    },
    {
      text: "What is the acceleration due to gravity on Earth?",
      options: ["9.8 m/s²", "3.5 m/s²", "12 m/s²", "6.7 m/s²"],
      correctIndex: 0,
    }
  ]
};
