// ... 保留 imports 和组件定义
// 在页面进入时添加动画和渐显效果

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle, XCircle, Zap, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { allQuestions } from "./questions";

// 声音资源
const audioCorrect = new Audio("/correct.mp3");
const audioWrong = new Audio("/wrong.mp3");
const audioCombo = new Audio("/combo.mp3");
const audioBoss = new Audio("/boss.mp3");

export default function ScienceQuizGame() {
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [stars, setStars] = useState(0);
  const [showCombo, setShowCombo] = useState(false);
  const [showBoss, setShowBoss] = useState(false);
  const [comboMessage, setComboMessage] = useState("");
  const [completed, setCompleted] = useState(false);

  const questions = allQuestions[difficulty];
  const current = questions[currentIndex];
  const progress = ((currentIndex + (answered ? 1 : 0)) / questions.length) * 100;

  useEffect(() => {
    if (currentIndex === questions.length - 1) {
      setShowBoss(true);
      audioBoss.play();
    } else {
      setShowBoss(false);
    }
  }, [currentIndex]);

  const handleSelect = (index: number) => {
    if (!answered && !completed) {
      setSelected(index);
      setAnswered(true);
      if (index === current.correctIndex) {
        setScore(score + 10);
        setStars(stars + 1);
        setShowCombo(true);
        setComboMessage("Mind Combo MAX! 🔥");
        audioCorrect.play();
        audioCombo.play();
        setTimeout(() => setShowCombo(false), 1000);
      } else {
        audioWrong.play();
      }
    }
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setSelected(null);
      setAnswered(false);
    } else {
      setCompleted(true);
    }
  };

  const handleChangeDifficulty = (level: 'easy' | 'medium' | 'hard') => {
    setDifficulty(level);
    setCurrentIndex(0);
    setSelected(null);
    setAnswered(false);
    setScore(0);
    setStars(0);
    setCompleted(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen bg-gradient-to-br from-green-200 via-green-100 to-green-300 p-4 flex flex-col items-center relative overflow-hidden"
    >
      <motion.div
        className="w-full max-w-3xl mb-4"
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        <Progress value={progress} className="h-4" />
        <div className="text-center mt-2 text-lg font-semibold">
          Question {currentIndex + 1} / {questions.length} (Difficulty: {difficulty})
        </div>
        <div className="flex justify-center gap-2 mt-2">
          <Button onClick={() => handleChangeDifficulty('easy')} variant={difficulty === 'easy' ? 'default' : 'outline'} size="sm">Easy</Button>
          <Button onClick={() => handleChangeDifficulty('medium')} variant={difficulty === 'medium' ? 'default' : 'outline'} size="sm">Medium</Button>
          <Button onClick={() => handleChangeDifficulty('hard')} variant={difficulty === 'hard' ? 'default' : 'outline'} size="sm">Hard</Button>
        </div>
      </motion.div>

      <AnimatePresence>
        {showCombo && (
          <motion.div
            className="absolute top-24 text-center text-4xl font-bold text-purple-600 drop-shadow-xl"
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1.3 }}
            exit={{ opacity: 0, scale: 0.5 }}
            transition={{ duration: 0.6 }}
          >
            <Zap className="inline-block mr-2 animate-bounce" /> {comboMessage}
          </motion.div>
        )}
      </AnimatePresence>

      {showBoss && (
        <motion.div
          className="absolute top-10 text-3xl font-extrabold text-red-600 animate-bounce"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
        >
          🚨 Final Boss Incoming! Ultimate Brain Challenge! 🚨
        </motion.div>
      )}

      <motion.div
        className="flex flex-col items-center space-y-4 w-full max-w-2xl"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <Card className="w-full bg-white/80 rounded-2xl shadow-xl">
          <CardContent className="p-6">
            <div className="text-xl font-bold mb-4">🧠 {current.text}</div>
            <div className="grid gap-3">
              {current.options.map((option, index) => {
                const isCorrect = index === current.correctIndex;
                const isSelected = selected === index;
                const showResult = answered;
                const resultIcon = isCorrect ? (
                  <CheckCircle className="ml-2 text-green-600" size={18} />
                ) : (
                  <XCircle className="ml-2 text-red-500" size={18} />
                );
                const bgClass =
                  showResult && isSelected
                    ? isCorrect
                      ? "border-green-500 bg-green-100 animate-pulse"
                      : "border-red-500 bg-red-100"
                    : "";

                return (
                  <Button
                    key={index}
                    variant="outline"
                    className={`rounded-xl justify-start ${bgClass}`}
                    onClick={() => handleSelect(index)}
                    disabled={answered || completed}
                  >
                    {option}
                    {showResult && isSelected && resultIcon}
                  </Button>
                );
              })}
            </div>
            {answered && (
              <div className="mt-4 text-center">
                <Button onClick={handleNext} className="rounded-full" disabled={completed}>
                  {currentIndex < questions.length - 1 ? "Next Question" : "Finish Quiz"}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <motion.img
          src="/fox-thinking.png"
          alt="Thinking Fox"
          className="w-32 h-auto"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5 }}
        />
      </motion.div>

      <motion.div
        className="fixed top-4 right-4 bg-white/80 rounded-2xl shadow-md p-3 w-44"
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.6 }}
      >
        <div className="font-semibold mb-1">Reward</div>
        <div className="flex items-center gap-2">
          <Star className="text-yellow-500" />
          <span>{stars} / {questions.length} stars</span>
        </div>
        <div className="mt-2">Knowledge ✨: +{score}</div>
      </motion.div>
    </motion.div>
  );
}
